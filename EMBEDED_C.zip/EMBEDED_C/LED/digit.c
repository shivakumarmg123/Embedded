#include"header.h"
main()
{
	int num,i;
	lcd_init();
	while(1)
	{
		for(i=0;i<10;i++)
		{
			lcd_cmd(0x01);
			lcd_cmd(0x80);
			lcd_data('0'+i);
			delay_ms(300);
		}
		i=0;
	}
}
