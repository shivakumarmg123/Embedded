#include<LPC21XX.H>
#include"header.h"
#define sw ((IOPIN0>>14)&1)//P0.14
main()
{
	int num,i;
	//IODIR0|=(1<<21);
	lcd_init();
	lcd_cmd(0x0c);
	while(1)
	{
	for(num=0;num<10; )
	{
		if(sw==0)
		{
			delay_ms(50);
			while(sw==0);
			num++;

//		if(num==10)
//		{
//			for(i=0;i<5;i++)
//			{
//				IOSET0=(1<<21);
//				delay_ms(500);
//				IOCLR0=(1<<21);
//				delay_ms(500);
//			}
//		}
	lcd_cmd(0x80);
	lcd_string("switch count=");
	lcd_data((num/10)+48);						   
	lcd_data((num%10)+48);
	}
	}
	}
}
		