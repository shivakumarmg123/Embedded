#include<LPC21XX.H>
#include"header.h"
#define sw1 ((IOPIN0>>14)&1)//P0.14
#define sw2 ((IOPIN0>>15)&1)//P0.15
main()
{
	int i,j,k,c=0;
	lcd_init();
	lcd_cmd(0x01);
	for(j=0;i<3;j++)
	{
		if(sw1==0)
		{
			delay_ms(50);
			while(sw1==0);
			c++;
			lcd_cmd(0x80);
			lcd_string("sw_count=");
			lcd_data(c);
			if(c==1)
			{
			for(i=0;i<24;)
			{
				if(sw2==0)
				{
					delay_ms(50);
					while(sw2==0);
					i++;
				}
			}
			if(c==2)
			{
			for(k=0;k<59;)
			{
				if(sw2==0)
				{
					delay_ms(50);
					while(sw2==0);
					k++;
				}
			}
			}
			c=0;
			}
		}
	}
}

				
