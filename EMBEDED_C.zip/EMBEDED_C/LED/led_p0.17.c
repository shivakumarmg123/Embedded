#include <LPC21xx.H>
#include "header.h"

main()
{
IODIR0|=(1<<17)|(1<<18)|(1<<19);
	while(1)
	{
	IOCLR0=(1<<17)|(1<<18)|(1<<19);
	delay_ms(100);
	IOSET0=(1<<17)|(1<<18)|(1<<19);
	delay_ms(100);
	}
}

