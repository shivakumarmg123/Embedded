#include<LPC21XX.H>
#include"header.h"
#define led1 (1<<17)
#define led2 (1<<18)
#define led3 (1<<19)
#define	sw_pin 14
#define sw ((IOPIN0>>sw_pin)&1)
main()
{
IODIR0=led1||led2||led3;
IODIR0&=~sw_pin;
while(1)
{
if(sw==0)
IOCLR0=led1||led2||led3;
else
IOSET0=led1||led2||led3;
}
}
