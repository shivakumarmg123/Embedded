#include<LPC21XX.H>
#include"header.h"
#define sw1 ((IOPIN0>>14)&1)
#define sw2 ((IOPIN0>>15)&1)
main()
{
	int num,num1,i;
	lcd_init();
		for(num=0;num<10;)
		{
		if(sw1==0)
		{
			delay_ms(50);
			while(sw1==0);
			num++;
			lcd_cmd(0x80);
			lcd_string("Time=");
			lcd_integer(num);
			
		 }
		 }
		 	num1=num;
			while(num1)
			{
			if (sw2==0)
			{
			delay_ms(50);
			while(sw2==0);
//			for(i=0;i<59;i++)
//			{
//				delay_s(1);
//			}
			num1--;
			lcd_cmd(0xc0);
			lcd_string("Time=");
			lcd_integer(num1);
			}
			}
			
}
