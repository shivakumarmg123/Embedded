#include<LPC21XX.H>
#include"header.h"
main()
{
	IODIR0|=0xff;
	while(1)
	{
		IOCLR0=0xff;
		delay_ms(100);
		IOSET0=0xff;
		delay_ms(100);
	}
}	



