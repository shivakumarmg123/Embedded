#include<LPC21XX.H>
#include"header.h"
#define RS (1<<8)
#define RW (1<<9)
#define EN (1<<10)
void lcd_init(void)
{
	IODIR0|=0X7FF;//P0.0-PO.10
	lcd_cmd (0x38);//set enable 8_bit_mode
	lcd_cmd (0x0E);//display cursor
	lcd_cmd (0x01);//cleare the screan
}
void lcd_data(unsigned char data)
{
	IOCLR0=0X7FF;
	IOSET0=data;
	IOSET0=RS;// RS=1
	IOCLR0=RW;//RW=0
	IOSET0=EN;//EN=1
	delay_ms(2);
	IOCLR0=EN;//EN=0
}
void lcd_cmd(unsigned char cmd)
{
	IOCLR0=0X7FF;
	IOSET0=cmd;
	IOCLR0=RS;//RS=0
	IOCLR0=RW;//RW=0
	IOSET0=EN; //EN=1
	delay_ms(2);
	IOCLR0=EN;//EN=0
}
