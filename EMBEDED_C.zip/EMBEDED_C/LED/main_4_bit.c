#include"header.h"
main()
{
int i,j=0,m;
char s[]="shivakumar";
lcd_init();
while(1)
{ 
	for(m=0;s[m];m++);
	lcd_cmd(0x0c);
  for(i=0;i<16;i++)
  {
  	if(i>=8)
	{
		//lcd_cmd(0x01);
		lcd_cmd(0x80);
		lcd_string(s+m-1-j++);
		delay_ms(100);
	}
  	//lcd_cmd(0x01);
  	lcd_cmd(0x80+i);
	lcd_string(s);
	delay_ms(100);
	lcd_cmd(0x01);
	
  }
  j=0;
}
}
  