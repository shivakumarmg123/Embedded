#include<LPC21XX.H>
#include"header.h"
#define LED1 (1<<17)
#define SW_PIN  14
#define SW ((IOPIN0>>SW_PIN)&1)
main()
{
.IODIR0|=LED1;
IODIR0&=~(1<<SW_PIN);
while(1)
{
if(SW==0)
IOCLR0=LED1;
else
IOSET0=LED1;
}
}
