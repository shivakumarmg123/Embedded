#include<LPC21XX.H>
#include "header.h"
main()
{
int i;
IODIR0=0X07;
while(1)
{
IOCLR0=0X07;
delay_ms(200);
for(i=0;i<=2;i++)
{
IOSET0=(1<<i);
delay_ms(200);
}
}
}
