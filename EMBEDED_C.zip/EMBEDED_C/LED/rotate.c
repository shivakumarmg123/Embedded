#include"header.h"
main()
{
int i,j=0,m,k,l,n;
char s[]="shivakumar",s1[]="vector";
for(n=0;s1[n];n++);
lcd_init();		  
while(1)
{ 
	for(m=0;s[m];m++);
	lcd_cmd(0x0c);
  for(i=0;i<=16;i++)
  {
  	if(i>=16-m+2)
	{
		lcd_cmd(0x80);
		lcd_string(s+m-1-j++);
		delay_ms(100);
		//lcd_cmd(0x01);
	}
	lcd_cmd(0x80+i);
	lcd_string(s);
//	lcd_string("shiva");
	delay_ms(100);
	lcd_cmd(0x01);
   }
   
  j=0;
  for(i=16;i>=0;i--)
  {
  	lcd_cmd(0x01);
  	lcd_cmd(0xc0+i);
	lcd_string(s1);
	delay_ms(100);

  }
  for(n=0;n<l;n++)
  {
  	lcd_cmd(0x01);
	lcd_cmd(0xc0+n);
	lcd_string(s1+n);
	delay_ms(100);
	}
}
}
  