#include<LPC21XX.H>
#include"header.h"
#define sw ((IOPIN0>>14)&1)//P0.14
main()
{
	int num,i,pos;
	lcd_init();
	lcd_cmd(0x0c);
	while(1)
	{
	for(num=0;num<65535; )
	{
		if(sw==0)
		{
			delay_ms(50);
			while(sw==0);
			num++;
		
		}
		lcd_cmd(0x80);
		lcd_string("sw_count=");
		lcd_integer(num);
		lcd_cmd(0xc0);
		for(pos=15;pos>=0;pos--)
		{
		lcd_data(((num>>pos)&1)+48);
		}
	}

	}
}
	