#include"header.h"
main()
{
	int num;
	lcd_init();
	while(1)
	{
		for(num=0;num<100;num++)
		{
			//lcd_cmd(0x01);
			lcd_cmd(0x80);
			lcd_data((num/10)+48);
			//lcd_cmd(0x80+1);
			lcd_data((num%10)+48);
			delay_ms(1000);
		}
		
	}
}