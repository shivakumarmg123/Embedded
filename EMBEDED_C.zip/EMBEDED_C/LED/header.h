extern void delay_ms(int ms);
extern void delay_s(int s);
extern void lcd_init(void);
extern void lcd_data(unsigned char data);
extern void lcd_cmd(unsigned char cmd);
extern void lcd_string(char *ptr);
extern void lcd_cgram(void);
extern void lcd_integer(int num);
extern void lcd_binary(short int num);
