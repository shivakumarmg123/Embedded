#include<LPC21XX.H>
#include"header.h"
main()
{
	lcd_init();
	lcd_integer(123456789);
	
}
