#include<LPC21XX.H>
void delay_ms(int ms)
{
T0PR=15000-1;
T0PC=T0TC=0;
T0TCR=1;
while(T0TC<ms);
T0TCR=0;
}
void delay_s(int s)
{
T0PR=15000000-1;
T0PC=T0TC=0;
T0TCR=1;
while(T0TC<s);
T0TCR=0;
}
