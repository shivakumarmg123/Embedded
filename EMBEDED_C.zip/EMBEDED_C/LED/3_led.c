#include<LPC21XX.H>
#include "header.h"
#define led (1<<5)
main()
{
  	IODIR0=led;
	while(1)
	{
	IOCLR0=led;
	delay_ms(100);
	IOSET0=led;
	delay_ms(100);
	}
}
