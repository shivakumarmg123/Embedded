#include<LPC21XX.H>
#include "header.h"
#define led1 (1<<17)
#define led2 (1<<18)
#define led3 (1<<19)
main()
{
IODIR0=led1|led2|led3;
while(1)
{
IOCLR0=led1|led2|led3;
delay_ms(100);
IOSET0=led1|led2|led3;
delay_ms(100);
}
}
