#include<LPC21XX.H>
#include"header.h"
#define led1 (1<<17)
#define led2 (1<<18)
#define led3 (1<<19)
main()
{
int i=0;
IODIR0=led1|led2|led3;
while(1)	
{
	for(i=0;i<8;i++)
	{
		IOCLR0=(i<<17);
		delay_ms(100);
		IOSET0=led1|led2|led3;
		delay_ms(100);
	
	}

}
}
