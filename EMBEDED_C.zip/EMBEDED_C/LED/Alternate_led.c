#include<LPC21XX.H>
#define led (0xff)
main()
{
int i;
IODIR0|=led;
while(1)
{
	IOCLR0=led;
	delay_ms(200);
	for(i=0;i<7;i=i+2)
	{
		IOSET0=(i<<1);
		delay_ms(200);
	}
		for(i=7;i>=1;i=i-2)
	{
		IOSET0=(1<<i);
		delay_ms(200);
	}

}
}
