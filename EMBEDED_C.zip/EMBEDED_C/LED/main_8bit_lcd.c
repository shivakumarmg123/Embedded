#include<LPC21XX.H>
#include"header.h"
main()
{	int i;
	lcd_init();
	lcd_cmd(0x80);
	while(1)
	{
	for(i=0;i<8;i++)
	{
	lcd_cmd(0x80+i);
	lcd_data(i+'A');
	//delay_ms(1000);
	//lcd_cmd(0x01);
	delay_ms(1000);
	}
	}
}
