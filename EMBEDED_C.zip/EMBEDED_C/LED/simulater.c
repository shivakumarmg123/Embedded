#include<LPC21XX.H>
#include"header.h"
main()
{
int i;
IODIR0=0X000E0000;
IOSET0=0X000E0000;
while(1)
{
for(i=0;i<8;i++)
{
	IOCLR0=0X000F0000;
	delay_ms(100);
	IOCLR0=0x000f0000;
}
}
}
