#include"header.h"
CAN1 v1;
main()
{
	can1_init();
	uart0_init(9600);
	uart0_tx_string("nodeB \r\n");
	while(1)
	{
		can1_rx(&v1);
		if(v1.rtr==0)
			uart0_tx_string("node: DATA_frame \r\n");
		else
		uart0_tx_string("node: REMOTE_freme \r\n");
	}
}
