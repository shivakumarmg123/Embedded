#include"header.h"
CAN1 v1,v2;
main()
{
	can1_init();
	v1.id=0x123;
	v1.rtr=0;
	v1.dlc=8;
	v1.byteA=0x44332211;
	v1.byteB=0x88776655;

	v2.id=0x1AF;
	v2.rtr=1;
	v2.dlc=4;
	while(1)
	{
	can1_tx(v1);
	delay_ms(100);
	can1_tx(v2);
	delay_ms(100);
	}
}
