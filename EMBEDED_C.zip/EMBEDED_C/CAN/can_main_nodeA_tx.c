#include<LPC21XX.H>
#include"header.h"
#define sw1 ((IOPIN0>>14)&1)
#define	sw2 ((IOPIN0>>15)&1)
CAN1 v1,v2;
main()
{
	can1_init();
	v1.id=0x123;
	v1.rtr=0;//data fream
	v1.dlc=1;
	v1.byteA=0x11;

	v2.id=0x123;
	v2.rtr=0;
	v2.dlc=1;
	v2.byteA=0x22;
	while(1)
	{
		if(sw1==0)
		{
			while(sw1==0);
			can1_tx(v1);
		}
		else if(sw2==0)
		{
			while(sw2==0);
			can1_tx(v2);
		}
	}
}
