#include<LPC21XX.H>
#include"header.h"
#define led1 (1<<17)
#define	led2 (1<<18)
//#define sw1 ((IOPIN0>>14)&1)
//#define	sw2 ((IOPIN0>>15)&1)
CAN1 v1;
main()
{
	   IODIR0|=led1|led2;
	   //IODIR0|=sw1|sw2;
	   can1_init();
	   uart0_init(9600);
	   uart0_tx_string("NODE_B \r\n");
	   while(1)
	   {
	   		can1_rx(&v1);
			if(v1.rtr==0)
			//if(sw1==0)
			{
				//while(sw1==0);
				uart0_tx_string("NODE_B: data_fream \r\n");
				IOCLR0=led2|led1;
			}
			else if(v1.rtr==1)
			//else if(sw2==0)
			{
				//while(sw2==0);
				uart0_tx_string("NODE_B: remote_fream \r\n");
				IOSET0=led1|led2;
			}
			
		}
}
