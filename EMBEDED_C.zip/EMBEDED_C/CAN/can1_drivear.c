#include<LPC21XX.H>
#include"header.h"
void can1_init(void)
{
	VPBDIV=1;
	PINSEL0|=0X00040000;//P0.23---->RD1
	C1MOD=1;// select a reset_bit
	C1BTR=0X001C001D;//set a 125-kbps baudrete
	AFMR=2;
	C1MOD=0;//cancel reset_mode
}
void can1_tx(CAN1 v)
{
	C1TID1=v.id;//11-bits id
	C1TFI1=(v.dlc<<16);//RTR=0,DLC,FF=0
	if(v.rtr==0)//if data fream
	{
		C1TDA1=v.byteA;
		C1TDB1=v.byteB;
	}
	else
	C1TFI1|=(1<<30);//RTR=1

	C1CMR=0X21;//start tx & select tx buf
	while(((C1GSR>>3)&1)==0);
}
// this fun is designed to receive DF/RF/RF
void can1_rx(CAN1 *ptr)
{
	while((C1GSR&1)==0);
	ptr->id=C1RID;
	ptr->rtr=(C1RFS>>30)&1;
	if(ptr->rtr==0)
	{
		ptr->byteA=C1RDA;
		ptr->byteB=C1RDB;
	}
	ptr->dlc=(C1RFS>>16)&0XF;
	C1CMR=(1<<2);//relese

}
