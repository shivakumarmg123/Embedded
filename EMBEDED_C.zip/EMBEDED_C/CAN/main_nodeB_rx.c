#include<LPC21XX.H>
#include"header.h"
#define led1 (1<<17)
#define	led2 (1<<18)
CAN1 v1;
main()
{
	   IODIR0|=led1|led2;
	   can1_init();
	   uart0_init(9600);
	   uart0_tx_string("NODE_B \r\n");
	   while(1)
	   {
	   		can1_rx(&v1);
			if(v1.rtr==0)
			{
				uart0_tx_string("NODE_B: data_fream \r\n");
				IOSET0=led1^led1;
			}
			else if(v1.rtr==1)
			{
				uart0_tx_string("NODE_B: remote_fream \r\n");
				IOSET0=led2^led2;
			}
		}
}