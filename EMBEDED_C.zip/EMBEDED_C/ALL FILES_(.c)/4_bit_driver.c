#include<LPC21XX.H>
#include"header.h"
#define RS (1<<17)//P0.17
#define RW (1<<18)//P0.18
#define EN (1<<19)//P0.19
typedef unsigned char u8;
typedef unsigned int u32;
void lcd_init(void)
{
	IODIR1=0X00FE0000;
	PINSEL2=0;// p1.16 - p1.31
	lcd_cmd(0x03);
	lcd_cmd(0x02);
	lcd_cmd(0x28);
	lcd_cmd(0x0E);
	lcd_cmd(0x01);
}
void lcd_data(u8 data)
{
	  u32 temp;
	  IOCLR1=0X00FE0000;
	  temp=(data & 0xF0)<<16;
	  IOSET1=temp;//higer 4_bits
	  IOSET1=RS;
	  IOCLR1=RW;
	  IOSET1=EN;
	  delay_ms(2);
	  IOCLR1=EN;

	  IOCLR1=0X00FE0000;
	  temp=(data & 0x0F)<<20;
	  IOSET1=temp;//lower_bits
	  IOSET1=RS;
	  IOCLR1=RW;
	  IOSET1=EN;
	  delay_ms(2);
	  IOCLR1=EN;
}
void lcd_cmd(u8 cmd)
{
	  u32 temp;
	  IOCLR1=0X00FE0000;
	  temp=(cmd & 0xF0)<<16;
	  IOSET1=temp;//higer 4_bits
	  IOCLR1=RS;
	  IOCLR1=RW;
	  IOSET1=EN;
	  delay_ms(2);
	  IOCLR1=EN;

	  IOCLR1=0X00FE0000;
	  temp=(cmd & 0x0F)<<20;
	  IOSET1=temp;//lower_bits
	  IOCLR1=RS;
	  IOCLR1=RW;
	  IOSET1=EN;
	  delay_ms(2);
	  IOCLR1=EN;
}
void lcd_integer(unsigned short int num)
{
	int i,a[10];
	if(num==0)
	lcd_data('0');
	if(num<0)
	lcd_data('-');
	i=0;
	while(num>0)
	{
		a[i]=num%10;
		num=num/10;
		i++;
	}
	for(--i;i>=0;i++)
	lcd_data(a[i]+48);
}
void lcd_string(char *p)
{
	while(*p!=0)
	{
		lcd_data(*p);
		p++;
	}
}
void lcd_tx_float(float num)
{
	char arr[10];
	sprintf(arr,"%.1f",num);
	lcd_string(arr);
}
																			                                       