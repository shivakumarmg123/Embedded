#include"header.h"
main()
{
	unsigned int temp;
	adc_init();
	lcd_init();
	uart0_init(9600);
	while(1)
	{
		temp=adc_read(2);
		lcd_cmd(0x01);
		lcd_integer(temp);
		uart0_tx_integer(temp);
		uart0_tx_string("\r\n");
		delay_ms(100);
	}
}
