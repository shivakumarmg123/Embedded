#include"header.h"
main()
{
	unsigned short int adcval;
	uart0_init(9600);
	spi0_init();
	uart0_tx_string("MCP3204 ADC \r\n");
	while(1)
	{
		adcval=mcp3204_read(2);
		uart0_tx_string("\r\n ch0= ");
		uart0_tx_integer(adcval);
		delay_ms(100);
	}
}							   
