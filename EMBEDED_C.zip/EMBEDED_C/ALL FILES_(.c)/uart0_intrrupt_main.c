#include"header.h"
int count1,count2;
main()
{
	uart0_init(9600);
	en_uart0_interrupt();
	while(1)
	{					 
		count1++;
	}
}
