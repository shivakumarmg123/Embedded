#include"header.h"
#include<LPC21XX.H>
#define LED1 (1<<17)
unsigned char opt;
main()
{
	uart0_init(9600);
	en_uart0_interrupt();
	IODIR0|=LED1;
	while(1)
	{
		while(opt=='a')
		{
			IOCLR0=LED1;
			delay_ms(10);
			IOSET0=LED1;
			delay_ms(10);
		}
		while(opt=='b')
		{
			IOCLR0=LED1;
			delay_ms(30);
			IOSET0=LED1;
			delay_ms(30);
		}
		while(opt!='a' && opt!='b')
		{
			IOSET0=LED1;
		}
	}
}

		 
