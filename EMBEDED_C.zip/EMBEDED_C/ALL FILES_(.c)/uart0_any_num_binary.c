 #include"header.h"
 main()
 {
 	char a[10];
	uart0_init(9600);
	while(1)
	{
		uart0_tx_string("\r\n enter an number: ");
		uart0_rx_string(a,9);
		uart0_tx_loopback(a);
		//uart0_tx_string(a);
		//while(uart0_rx()!='\r');
		uart0_tx_string("\r\n binary: ");
		//uart0_integer(temp);
		uart0_string_binary(a);
	}
}
		
			
