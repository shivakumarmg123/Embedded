#include<LPC21XX.H>
//extern int count2;
//void uart0_handler(void)__irq
//{
//	int temp=U0IIR;
//	unsigned char dummy;
//	if((temp^0x04)==0)
//	{
//		dummy=U0RBR;
//		count2++;
//	}
//	VICVectAddr=0;
//}
//////////// intrapt led//////////////
extern unsigned char opt;
void UART0_handler(void)__irq
{
	int temp=U0IIR;
	if((temp^0x4)==0)
	{
		opt=U0RBR;
		U0THR=opt;
	}
	VICVectAddr=0;
}
void en_uart0_interrupt(void)
{
	//VICIntSelect=0;
	VICIntSelect=(1<<16);
	//VICVectCntl0=6|(1<<5);
	//VICVectAddr0=(int)uart0_handler;
	U0IER=1;
	VICIntEnable|=(1<<6);
}
