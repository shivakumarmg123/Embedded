#include<LPC21XX.H>
#include"header.h"
main()
{
//	char a[20];
//	int b[20];
//	int i=0,j=0,num1=0,num2,op,l=0,temp;
	uart0_init(9600);
	while(1)
	{
		char a[20];
		int b[20];
		int i=0,j=0,num1=0,num2,op,l=0,m=0,n=0,l1;

		uart0_tx_string("\r\n enter an expration= ");
		uart0_rx_string(a,19);
		uart0_tx_loopback(a);

			for(i=0,num1=0;a[i];i++)
			{
				if(a[i]>='0' && a[i]<='9')
				{
				num1=num1*10+a[i]-48;
				b[j]=num1;
				}
				else if(a[i]=='('||a[i]==')'||a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='%')
				{					 
				j++;
				b[j++]=a[i];
				l=l+2;
				num1=0;
				}
			   
			}
//		  for(i=0;i<=l;i++)
//		  {
//		  		if(b[i]=='(')
//				m=i;
//				else if(b[i]==')')
//				n=i;
//		  }	
//		  l1=n-m;
//
//		  for(i=m;b[i]!=')';i++)
//		  {
//			  		if(b[i]=='*'||b[i]=='/'||b[i]=='%')
//					{
//					op=b[i];
//					num1=b[i-1];
//					num2=b[i+1];
//					b[i-1]=function(num1,op,num2);
//							for(j=i;j<=l;j++)
//							b[j]=b[j+2];
//							l=l-2;
//							n=n-2;
//							i--;
//					}
//		   }
//		   for(i=m;i<=n;i++)
//		   {
//				    if(b[i]=='+'||b[i]=='-')
//					{
//					op=b[i];
//					num1=b[i-1];
//					num2=b[i+1];
//					b[i-1]=function(num1,op,num2);
//							for(j=i;j<=l;j++)
//							b[j]=b[j+2];
//							l=l-2;
//							n=n-2;
//							i--;
//					}
//		    }
//			b[i-3]=b[i-2];
//			for(i=i-2;i<=2;i++)
//				b[i]=b[i+2];
//				l=l-2;

		  	  for(i=0;i<=l;i++)
			  {
			  		if(b[i]=='*'||b[i]=='/'||b[i]=='%')
					{
					op=b[i];
					num1=b[i-1];
					num2=b[i+1];
					b[i-1]=function(num1,op,num2);
							for(j=i;j<=l;j++)
							b[j]=b[j+2];
							l=l-2;
							i--;
					}
				}
			   for(i=0;i<=l;i++)
			   {
				    if(b[i]=='+'||b[i]=='-')
					{
					op=b[i];
					num1=b[i-1];
					num2=b[i+1];
					b[i-1]=function(num1,op,num2);
							for(j=i;j<=l;j++)
							b[j]=b[j+2];
							l=l-2;
							i--;
					}
				}		
		   			

		 uart0_tx_string("\n\r result= ");
		 uart0_tx_integer(b[0]);
		}	
}
