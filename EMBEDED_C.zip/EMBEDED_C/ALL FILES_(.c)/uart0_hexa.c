#include"header.h"
main()
{
    char a[10];
	uart0_init(9600);
	while(1)
	{
		uart0_tx_string("\r\n enter an char: ");
		uart0_rx_string(a,9);
		uart0_tx_loopback(a);
		while(uart0_rx()!='\r');
		uart0_tx_string("\r\n HEXA:0x");
		uart0_hexa(a);
	}

}
