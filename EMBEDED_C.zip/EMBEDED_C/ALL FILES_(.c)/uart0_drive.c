#include<LPC21XX.H>
#include"header.h"
void uart0_init(unsigned int baud)
{
	int a[]={15,60,30,15,15};
	unsigned int result=0,pclk;
	pclk=a[VPBDIV]*1000000;
	result=pclk/(16*baud);
	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=result & 0xff;
	U0DLM=(result >> 8)& 0xff;
	U0LCR=0x03;
}
#define THER ((U0LSR >> 5)&1)
void uart0_tx(unsigned char data)
{
	U0THR=data;
	while(THER==0);
}
#define RDR (U0LSR & 1)	
unsigned char uart0_rx(void)
{
	while(RDR==0);	
	return U0RBR;
}
//#define RDR (U0LSR & 1)
void uart0_rx_string(char *ptr,int max_bytes)
{
	int i;
	for(i=0;i<max_bytes;i++)
	{
		while(RDR==0);

		ptr[i]=U0RBR;
		if( ptr[i]=='\r')
		break;
		
	}
	ptr[i]='\0';
}	
	
void uart0_tx_string(char *p)
{
	while(*p!=0)
	{
		U0THR=*p;
		while(THER==0);
		p++;
	}
}
void uart0_integer(int num)
{
	int a[10],i=0;
	if(num==0)
	uart0_tx('0');
	if(num<0)
	uart0_tx('-');
	while(num>0)
	{
		a[i++]=num%10;
		num=num/10;
	}
	for(--i;i>=0;i--)
	uart0_tx(a[i]+48);
}
void uart0_binary(int p)
{
	int pos,num=p;
	if(num>=97 && num<=122 || num>=65 && num<=91)
	num=num;
	else
	num=num-48;
	 for(pos=7;pos>=0;pos--)
			uart0_tx((num>>pos&1)+48);
}

void uart0_string_binary(char *p)
{
    int num=0,pos,i;

	for(i=0;p[i];i++)
	{
		p[i]=p[i]-48;
		num=num*10+p[i];
	}
	if(num>255)
	 uart0_tx_string("\r\n enter the numbers b/w 0 to 255");
	 else
	 {
	 for(pos=7;pos>=0;pos--)	
			uart0_tx((num>>pos&1)+48);
	 }
}
void uart0_hexa(char *p)
{
	int a[10],i=0,temp=0;
	for(i=0;p[i];i++)
	{
		p[i]=p[i]-48;
		temp=temp*10+p[i];
	}
	while(temp)
	{	
		//i=0;
		if((temp%16)<10)
		a[i++]=(temp%16)+48;
		else
		a[i++]=(temp%16)+55;
		temp=temp/16;
	}
	a[i]='\0';
	for(--i;i>0;i--)
	uart0_tx(a[i]);
}
void uart0_tx_loopback(char *p)
{
	int i;
	for(i=0;p[i];i++)
	uart0_tx(p[i]);
}
void uart0_tx_integer(unsigned int num)
{
	char arr[10];
	sprintf(arr,"%d",num);
	uart0_tx_string(arr);
}
void uart0_tx_float(float num)
{
	char arr[10];
	sprintf(arr,"%.1f",num);
	uart0_tx_string(arr);
}
int function(int num1,int op,int num2)
{
		int result;
		switch(op)
		{
			case '+':result=num1 + num2;
					break;
			case '-':result=num1 - num2;
					break;
			case '*':result=num1 * num2;
					break;
			case '%':result=num1 % num2;
					break;
			case '/':result=num1 / num2;
					break;
		 default:uart0_tx_string("\n\r unknown option");
		}
		return result;
}



