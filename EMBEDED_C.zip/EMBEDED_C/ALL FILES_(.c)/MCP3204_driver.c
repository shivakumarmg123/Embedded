#include<LPC21XX.H>
#include"header.h"
#define CS0 (1<<7)
unsigned short int mcp3204_read(unsigned char ch_num)
{
	unsigned short int result=0;
	unsigned char byteH=0,byteL=0,channel=0;
	channel=ch_num<<6;
	IOCLR0=CS0;
	spi0(0x06);
	byteH=spi0(channel);
	byteL=spi0(0x0);
	IOSET0=CS0;
	byteH &=0x0f;
	result = (byteH << 8 ) | byteL;
	return result;
}
//void converting_float(unsigned short int adc0)
//{
//	float temperature,vout;
////	uart0_tx_string("\r\n ch0=");
////	uart0_tx_integer(adc0);
//		vout=(adc0*3.3)/1023;		
//		temperature=(vout-0.5)/0.01;
////		uart0_tx_string("\r\n TEMP= ");
////		uart0_tx_float(temperature);
////		lcd_tx_float(temperature);
//}

