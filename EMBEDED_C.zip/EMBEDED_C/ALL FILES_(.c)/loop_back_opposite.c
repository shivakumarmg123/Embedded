#include"header.h"
main()
{
	unsigned char temp;
	char ch,ch1;
	int i;
	uart0_init(9600);
	//lcd_init();
	while(1)
	{
		temp=uart0_rx();
		if(temp>='A' && temp<='Z' || temp>='a' && temp<='z')
		{
			for(i=0,ch='A',ch1='a';i<=25;i++,ch++,ch1++)
			{
				if(ch==temp || ch1==temp)
			 		uart0_tx(temp+(25-i)-i);
			}
			//temp=temp^32;
		//uart0_tx(temp);
		}											
	}
}
