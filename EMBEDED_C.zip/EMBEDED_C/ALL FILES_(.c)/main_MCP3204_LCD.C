#include<LPC21XX.H>
#include"header.h"
#define sw1 ((IOPIN0>>14)&1)// external adc
#define sw2 ((IOPIN0>>15)&1)// internal adc
main()
{
	unsigned short int adc0,adc1,adc2;
	float temperature,vout;
	int c=0;
	unsigned int temp;
	IODIR0&=~sw1;
	lcd_init();
	uart0_init(9600);
	spi0_init();
	adc_init();
	uart0_tx_string("MCP3204 ADC \r\n");
	while(1)
	{
		if(sw1==0)
		{
			while(sw1==0);
//			c++;
//			if(c%2==0)
//			{
			lcd_cmd(0x01);	
			adc0=mcp3204_read(0);
			lcd_cmd(0x80);
			lcd_string("CH0=");
				vout=(adc0*3.3)/1023;		
				//temperature=(vout-0.5)/0.01;
					lcd_tx_float(vout);
					lcd_cmd(0x8d);
					lcd_string("'EX'");
	
			adc1=mcp3204_read(1);
			lcd_cmd(0xC0);
			lcd_string("CH1=");
				vout=(adc1*3.3)/1023;		
				//temperature=(vout-0.5)/0.01;
					lcd_tx_float(vout);

			adc2=mcp3204_read(2);
			lcd_cmd(0xC8);
			lcd_string("CH2=");
				vout=(adc2*3.3)/1023;		
				//temperature=(vout-0.5)/0.01;
					lcd_tx_float(vout);
//						adc2=(adc2/1300)*100;
//						lcd_integer(adc2);
//						lcd_data('%');
					delay_ms(100);
		}
		if(sw2==0)
		{
			while(sw2==0);

				lcd_cmd(0x01);
				lcd_cmd(0x80);
				lcd_string("TEMP_CH0=");
				temp=adc_read(1);
				uart0_tx_string("\r\n CH0_TEMP=");
				uart0_tx_integer(temp);
				vout=(temp*3.3)/1023;		
				temperature=(vout-0.5)/0.01;
				lcd_tx_float(temperature);
				lcd_cmd(0x8e);
				lcd_string("IN");
				
				lcd_cmd(0xc0);
				lcd_string("CH1=");
				temp=adc_read(2);
				uart0_tx_string("\r\n CH1_TEMP=");
				uart0_tx_integer(temp);
				vout=(temp*3.3)/1023;		
				temperature=(vout-0.5)/0.01;
				lcd_tx_float(temperature);
				delay_ms(100);
				
		}
	}
}
