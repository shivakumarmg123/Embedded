#include"header.h"
#include<LPC21XX.H>
#define sw ((IOPIN0>>14)&1)
main()
{
	unsigned char count=48;
	IODIR0|=~sw;
	uart0_init(9600);
	uart0_tx_string("\r\n switch_count: ");
	while(1)
	{
		if(sw==0)
		{
			while(sw==0);
			count++;
			uart0_integer(count);
			if(count==100)
			count=48;
		}
	}
}
