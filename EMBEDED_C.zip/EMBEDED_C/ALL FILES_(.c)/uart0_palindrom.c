#include"header.h"
main()
{
	char a[50];
	int i,l,temp;
	uart0_init(9600);
	while(1)
	{
		uart0_tx_string("\r\n enter an string: ");
		uart0_rx_string(a,49);
		uart0_tx_loopback(a);
		//temp=uart0_palindrom(a);
		for(l=0;a[l];l++);
		for(i=0,l=l-1;l>=i;i++,l--)
		{	
			if(a[i]==a[l])
			temp=1;
			else
			{
			temp=0;
			break;
			}
		}
			
		if(temp==1)
		uart0_tx_string("\r\n palindrom");
		else
		uart0_tx_string("\r\n Not palindrom");
	}
}



