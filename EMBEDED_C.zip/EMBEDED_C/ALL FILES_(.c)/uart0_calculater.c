#include<LPC21XX.H>
#include"header.h"
main()
{
	char a[80];
	int i,num1=0,num2=0,op,result;
	uart0_init(9600);
	while(1)
	{
		uart0_tx_string("\r\n enter an expration= ");
		uart0_rx_string(a,12);
		uart0_tx_loopback(a);
		for(i=0;a[i];i++)
		{
			if(a[i]>='0'&& a[i]<='9')
			num1=num1*10+a[i]-48;
			else
			break;
		}
		op=a[i];
		for(++i;a[i];i++)
		num2=num2*10+a[i]-48;
		//result=num1 op num2;
		switch(op)
		{
			case '+':result=num1 + num2;
					 break;
			case '-':result=num1 - num2;
					 break;
			case '*':result=num1 * num2;
					 break;
			case '/':result=num1 / num2;
					 break;
			case '%':result=num1 % num2;
					 break;
			default:uart0_tx_string("\r\n un known operent");
		}
		uart0_tx_string("\r\n result= ");
		uart0_integer(result);
	}
}
