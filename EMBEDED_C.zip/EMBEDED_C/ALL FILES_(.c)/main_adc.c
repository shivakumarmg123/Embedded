#include"header.h"
main()
{
	unsigned int temp;
	adc_init();
	lcd_init();
	while(1)
	{
		temp=adc_read(2);
		lcd_cmd(0x01);
		lcd_integer(temp);
		//lcd_data('a');
		delay_ms(1000);
	}
}
