#include"header.h"
main()
{
	unsigned char temp;
	uart0_init(9600);
	while(1)
	{
	uart0_tx_string("\r\n enter an char: ");
	temp=uart0_rx();
	uart0_tx(temp);
	while(uart0_rx()!='\r');
	uart0_tx_string("\r\n decimal: ");
	uart0_integer(temp);
	}
}

