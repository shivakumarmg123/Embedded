#include "header.h"
main()
{
	unsigned char temp;
	uart0_init(9600);
	//lcd_init();
	while(1)
	{
		temp=uart0_rx();
		uart0_tx(temp);
		//lcd_data(temp);
	}
}
