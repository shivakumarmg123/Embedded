#include"header.h"
#include<LPC21XX.H>
#define LED1 (1<<17)
#define LED2 (1<<18)
main()
{
	unsigned char temp;
	IODIR0|=LED1|LED2;
	uart0_init(9600);
	uart0_tx_string("\r\n MENU:\r\n a)LED1_ON \r\n b)LED2_ON\r\n c)LED1_OFF \r\n d)LED2_OFF\r\n e)all_LEDS_ON\r\n f)all_LRDS_OFF\r\n");
	while(1)
	{
		temp=uart0_rx();
		uart0_tx(temp);
	
			switch(temp)
			{
				case 'a': IOSET0=LED1;// LED2 ON
							break;
				case 'b': IOSET0=LED2; // LED2 ON
							break;
				case 'c': IOCLR0=LED1;// LED2 OFF
							break;
				case 'd': IOCLR0=LED2;// LED2 OFF
							break;
				case 'e': IOSET0=LED1 | LED2;// BOTH ON
							break;
				case 'f': IOCLR0=LED1 | LED2; // BOTH OFF
							break;
				default: uart0_tx_string("\r\nunknown option\r\n");
			}
		}
}
