#include"header.h"
main()
{
	unsigned char h,m,s;
	i2c_init();
	lcd_init();
//	lcd_cmd(0x80);
//	lcd_string("shiva");

	i2c_byte_write_frame(0xd0,0x2,0x23);
	i2c_byte_write_frame(0xd0,0x1,0x59);
	i2c_byte_write_frame(0xd0,0x0,0x55);

	while(1)
	{
		h=i2c_byte_read_frame(0xd0,0x2);
		m=i2c_byte_read_frame(0xd0,0x1);
		s=i2c_byte_read_frame(0xd0,0x0);

		lcd_cmd(0x80);
		lcd_data((h/0x10)+48);
		lcd_data((h%0x10)+48);
		lcd_data(':');

		lcd_data((m/0x10)+48);
		lcd_data((m%0x10)+48);
		lcd_data(':');

		lcd_data((s/0x10)+48);
		lcd_data((s%0x10)+48);
		lcd_data(':');
	} 
}
