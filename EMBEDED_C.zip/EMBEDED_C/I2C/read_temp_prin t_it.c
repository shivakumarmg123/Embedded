#include"header.h"
main()
{
	unsigned int temp;
	float vout,temperature;
	adc_init();
	uart0_init(9600);
	while(1)
	{
		temp=adc_read(1);
		vout=(temp*3.3)/1023;		
		temperature=(vout-0.5)/0.01;
		uart0_tx_string("\r\n TEMP= ");
		uart0_tx_float(temperature);
		uart0_tx_string("0c");//shoing out put degree celcias
		delay_ms(100);
	}
}
