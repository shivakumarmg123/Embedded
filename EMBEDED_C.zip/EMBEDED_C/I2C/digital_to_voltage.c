#include"header.h"
main()
{
	unsigned int temp;
	float v;
#include <LPC21xx.H>
	adc_init();
	uart0_init(9600);
	while(1)
	{
		temp=adc_read(2);
		v=(temp*3.3)/1023;
		uart0_tx_integer(temp);
		uart0_tx(' ');
		uart0_tx_float(v);
		uart0_tx_string("\r\n");
		delay_s(1);
	}
}

		